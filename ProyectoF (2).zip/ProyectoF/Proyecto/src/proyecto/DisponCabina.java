/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell 7490
 */
public class DisponCabina {
    private boolean[] horarios;
   
    public DisponCabina() { //constructor vacío
        horarios = new boolean[10];

    }

    public DisponCabina(boolean[] horarios) {
        this.horarios = horarios;
    }    

    public String mostrarDispo() {
        StringBuilder sb = new StringBuilder("La disponibilidad de la cabina es:");
        for (int i = 0; i < horarios.length; i++) {
            int hora = 9 + i;
            sb.append(hora).append(":00 - ").append(horarios[i] ? "ocupado" : "disponible").append("\n");
        }
        return sb.toString();
    }

    public void reservaC() {
        String input = JOptionPane.showInputDialog(null,mostrarDispo() + "Ingrese la hora que desea reservar(debe estar entre 9 y 18)");
        try{
            int hora = Integer.parseInt(input);
            if (hora<9 || hora>18){
                JOptionPane.showMessageDialog(null, "La hora es inválida, debe estar entre 9 y 18");
                return;
            }
            int index= hora - 9;
            if(horarios[index]){
                JOptionPane.showMessageDialog(null, "Lo sentimos, este horario ya está reservado");
            } else{
                horarios[index]=true;
                JOptionPane.showMessageDialog(null, "Su reserva ha sido confirmada para las" + hora + ":00");
            } 
        } 
        catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(null, "Entrada no válida");
                    
                    }
            
        }
    public void liberarC() {
        String input = JOptionPane.showInputDialog(null,mostrarDispo() + "Ingrese la hora que desea liberar(debe estar entre 9 y 18)");
        try{
            int hora = Integer.parseInt(input);
            if (hora<9 || hora>18){
                JOptionPane.showMessageDialog(null,mostrarDispo()+ "La hora es inválida, debe estar entre 9 y 18");
                return;
            }
            int index= hora - 9;
            if(!horarios[index]){
                JOptionPane.showMessageDialog(null, "Este horario no está reservado");
            } else{
                horarios[index]=false;
                JOptionPane.showMessageDialog(null, "Su reserva ha sido cancelada para las" + hora + ":00");
            } 
        } 
        catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(null, "Entrada no válida");
                    
                    }
            
        
}

    
}
