/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell 7490
 */
public class ClasesEnGrupo {
    // como yoga,crossfit, funcionales, pilates, zumba, entre otras.
    // atributos 
    private String horario;
    private String nombre;
    private int capMaxima;
    Socio[] inscritos;
    int inscritosActual;
    private ArrayList<String> inscrito;

    public ClasesEnGrupo() { //constructor vacío
    }

    public ClasesEnGrupo(String horario, String nombre, int capMaxima) {
        this.horario = horario;
        this.nombre = nombre;
        this.capMaxima = capMaxima;
        this.inscritos = new Socio[capMaxima];
        this.inscritosActual = 0;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapMaxima() {
        return capMaxima;
    }

    public void setCapMaxima(int capMaxima) {
        this.capMaxima = capMaxima;
    }

    public Socio[] getInscritos() {
        return inscritos;
    }

    public void setInscritos(Socio[] inscritos) {
        this.inscritos = inscritos;
    }

    public int getInscritosActual() {
        return inscritosActual;
    }

    public void setInscritosActual(int inscritosActual) {
        this.inscritosActual = inscritosActual;
    }
    

    public boolean registroDeSocio(int socio){
        if(inscritosActual< capMaxima){
            inscritos[inscritosActual++]= new Socio(socio);
            return true;
        }
        return false;
    }
    
    public boolean cancelacionClase(int indice, String idSocio){
        for (int i = 0; i < inscritosActual; i++) {
            if(inscritos[i].equals(idSocio)){
                inscritos[i]=inscritos[inscritosActual-1];
                inscritos[inscritosActual-1]=null;
                inscritosActual--;
                return true;
            }
            
        }
        return false;
    }
    
    public boolean eliminaReg(String idSocio){
        return inscrito.remove(idSocio);
 
    }
    
    public void modificacionesClases(int indice, String nuevoNombre, String nuevoHorario, int nuevaCapacidad){
        this.nombre= nuevoNombre;
        this.horario= nuevoHorario;
        
        if(nuevaCapacidad != this.capMaxima){
            Socio[] nuevosSocios = new Socio[nuevaCapacidad];
            int cantAnterior = Math.min(nuevaCapacidad, inscritosActual);
            for (int i = 0; i < cantAnterior; i++) {
                nuevosSocios[i]= inscritos[i];
                }
            inscritos= nuevosSocios;
            inscritosActual= cantAnterior;
            capMaxima= nuevaCapacidad;
        }
        
    }
    
    public StringBuilder informacion(){
        StringBuilder info= new StringBuilder();
        info.append("Nombre: ").append(nombre).append("\n");
        info.append("Horario: ").append(horario).append("\n");
        info.append("Capacidad: ").append(capMaxima).append("\n");                
        info.append("Inscritos: ").append(inscritosActual).append("\n");
        for (int i = 0; i < inscritosActual; i++) {
            info.append(inscritos[i].getCodigo()).append("");
            
        }
        return info;
    }
    
    public void Informacion(){
        JOptionPane.showMessageDialog(null, "ClasesEnGrupo{" + "horario=" + horario + ", nombre=" + nombre + ", capMaxima=" + capMaxima + ", inscritos=" + inscritosActual + '}');
        for (int i = 0; i < inscritosActual; i++) {
            JOptionPane.showMessageDialog(null, inscritos[i] + "");
            
        }
    }
    
    public boolean socioRegistrado(String idSocio){
        for(int i=0;i<inscritosActual;i++){
            if(inscritos[i].equals(idSocio)){
                return true;
            }
        }
        return false;
    }

    void registroDeSocio(String idSocio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

       
}
