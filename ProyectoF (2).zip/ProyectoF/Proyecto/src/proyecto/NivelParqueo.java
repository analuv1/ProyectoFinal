/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author aliso
 */
public class NivelParqueo {
    private Espacio[][] espacios;
    private String nombre;

    public NivelParqueo(int filas, int columnas, String nombre) {
        this.nombre = nombre;
        espacios = new Espacio[filas][columnas];

        // inicializa con 3 discapacitados y 2 entrenadores en posiciones fijass
       espacios[0][0] = new Espacio("D");
       espacios[0][1] = new Espacio("D");
       espacios[0][2] = new Espacio("D"); 
       espacios[1][0] = new Espacio("E");
       espacios[1][1] = new Espacio("E"); 


        // el resto son espacios libres normales "L"
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (espacios[i][j] == null) {
                    espacios[i][j] = new Espacio("L");
                }
            }
        }
    }

    public boolean asignarEspacio(String idSocio, boolean esDiscapacitado, boolean esEntrenador) {
        for (int i = 0; i < espacios.length; i++) {
            for (int j = 0; j < espacios[0].length; j++) {
                String tipo = espacios[i][j].getEstado();

                if (tipo.equals("D") && esDiscapacitado && espacios[i][j].estaLibre()) {
                    espacios[i][j].setEstado("O");
                    espacios[i][j].setIdSocio(idSocio);
                    return true;
                }

                if (tipo.equals("E") && esEntrenador && espacios[i][j].estaLibre()) {
                    espacios[i][j].setEstado("O");
                    espacios[i][j].setIdSocio(idSocio);
                    return true;
                }

                if (tipo.equals("L") && espacios[i][j].estaLibre() && !esDiscapacitado && !esEntrenador) {
                    espacios[i][j].setEstado("O");
                    espacios[i][j].setIdSocio(idSocio);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean liberarEspacio(String idSocio) {
        for (int i = 0; i < espacios.length; i++) {
            for (int j = 0; j < espacios[0].length; j++) {
                if (espacios[i][j].getIdSocio().equals(idSocio)) {
                    espacios[i][j].resetearEstado();
                    return true;
                }
            }
        }
        return false;
    }

    public String mostrarNivel() {
        StringBuilder resultado = new StringBuilder();
        resultado.append("Nivel ").append(nombre).append(":\n");
        for (int i = 0; i < espacios.length; i++) {
            for (int j = 0; j < espacios[0].length; j++) {
                resultado.append(espacios[i][j].toString()).append(" ");
            }
            resultado.append("\n");
        }
        return resultado.toString();
    }
}
