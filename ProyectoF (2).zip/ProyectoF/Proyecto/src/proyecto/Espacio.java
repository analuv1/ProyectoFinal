/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author aliso
 */
public class Espacio {
    private String estado; // "L" = Libre, "O" = Ocupado, "D" = Discapacitado, "E" = Entrenador
    private String idSocio;
    private String tipoOriginal; // guarda el estado original: L, D o E

    public Espacio(String estado) {
        this.estado = estado;
        this.tipoOriginal = estado; // se guarda el tipo original al crearlo
        this.idSocio = "";
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdSocio() {
        return idSocio;
    }

    public void setIdSocio(String idSocio) {
        this.idSocio = idSocio;
    }

    // devuelve true si el espacio está disponible para ocupar
    public boolean estaLibre() {
        return estado.equals("L") || estado.equals("D") || estado.equals("E");
    }

    // restaura el estado original del espacio cuando se libera
    public void resetearEstado() {
        this.estado = tipoOriginal;
        this.idSocio = "";
    }

    @Override
    public String toString() {
        return estado;
    }
}

